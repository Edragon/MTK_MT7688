//
//  MTKAppDelegate.h
//  iottest
//
//  Created by 杨源 on 14-5-25.
//  Copyright (c) 2014年 mediatek. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MTKAppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end
