//
//  main.m
//  iottest
//
//  Created by 杨源 on 14-5-25.
//  Copyright (c) 2014年 mediatek. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "MTKAppDelegate.h"

int main(int argc, char * argv[])
{
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([MTKAppDelegate class]));
    }
}
